package ro.vision.launcher

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class WeatherInfo(val temp: Int, val desc: String)

/** Vremea de la Open-Meteo (gratuit, fără cheie). Implicit: București. */
object Weather {

    const val LAT = 44.4268
    const val LON = 26.1025

    fun fetch(): WeatherInfo? {
        return try {
            val url = URL("https://api.open-meteo.com/v1/forecast?latitude=$LAT&longitude=$LON&current_weather=true")
            val c = url.openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 8000
            val body = c.inputStream.bufferedReader().use { it.readText() }
            c.disconnect()
            val cw = JSONObject(body).getJSONObject("current_weather")
            WeatherInfo(Math.round(cw.getDouble("temperature")).toInt(), describe(cw.getInt("weathercode")))
        } catch (e: Exception) {
            null
        }
    }

    private fun describe(code: Int): String = when (code) {
        0 -> "Senin"
        1, 2 -> "Parțial noros"
        3 -> "Noros"
        45, 48 -> "Ceață"
        51, 53, 55, 56, 57 -> "Burniță"
        61, 63, 65, 66, 67, 80, 81, 82 -> "Ploaie"
        71, 73, 75, 77, 85, 86 -> "Ninsoare"
        95, 96, 99 -> "Furtună"
        else -> ""
    }
}
