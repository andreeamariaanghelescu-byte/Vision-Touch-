package ro.vision.launcher

import android.content.Context
import android.content.Intent
import android.media.tv.TvContract
import android.widget.Toast

object TvHelper {

    const val PREFS = "vl"
    const val KEY_TV_PKG = "tv_pkg"
    const val KEY_HOME_TV = "home_opens_tv"

    // Aplicații de TV live întâlnite pe televizoare Android (MediaTek / Amlogic / generic)
    private val KNOWN_TV_PACKAGES = listOf(
        "com.mediatek.wwtv.tvcenter",
        "com.droidlogic.tv.settings.tvsource",
        "com.droidlogic.tvsource",
        "com.google.android.tv",
        "com.android.tv",
        "org.droidtv.channels",
        "com.sony.dtv.tvx",
        "com.tcl.tv",
        "com.realtek.tv"
    )

    /** Deschide lista de canale a televizorului. Returnează false dacă nu a găsit nimic. */
    fun openChannels(ctx: Context): Boolean {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

        // 1) aplicația aleasă manual de utilizator
        prefs.getString(KEY_TV_PKG, null)?.let { if (launchPackage(ctx, it)) return true }

        // 2) intent standard de TV (canale)
        try {
            val i = Intent(Intent.ACTION_VIEW, TvContract.Channels.CONTENT_URI)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (i.resolveActivity(ctx.packageManager) != null) {
                ctx.startActivity(i)
                return true
            }
        } catch (e: Exception) { /* încercăm mai departe */ }

        // 3) pachete cunoscute
        for (pkg in KNOWN_TV_PACKAGES) {
            if (launchPackage(ctx, pkg)) return true
        }
        return false
    }

    fun launchPackage(ctx: Context, pkg: String): Boolean {
        return try {
            val pm = ctx.packageManager
            val i = pm.getLeanbackLaunchIntentForPackageCompat(pkg) ?: pm.getLaunchIntentForPackage(pkg)
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i)
                true
            } else false
        } catch (e: Exception) {
            false
        }
    }

    fun toastNoTv(ctx: Context) {
        Toast.makeText(ctx, R.string.no_tv, Toast.LENGTH_LONG).show()
    }
}

// getLeanbackLaunchIntentForPackage există doar de la API 21; minSdk e 21, deci e sigur.
private fun android.content.pm.PackageManager.getLeanbackLaunchIntentForPackageCompat(pkg: String): Intent? =
    getLeanbackLaunchIntentForPackage(pkg)
