package ro.vision.launcher

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.widget.ImageView
import java.net.URL
import java.util.concurrent.Executors

/** Încărcător minimalist de imagini, fără biblioteci externe. */
object ImageLoader {
    private val pool = Executors.newFixedThreadPool(3)
    private val ui = Handler(Looper.getMainLooper())
    private val cache = object : android.util.LruCache<String, Bitmap>(24) {}

    fun load(url: String, view: ImageView) {
        view.tag = url
        cache.get(url)?.let { view.setImageBitmap(it); return }
        pool.execute {
            try {
                val c = URL(url).openConnection()
                c.connectTimeout = 8000
                c.readTimeout = 8000
                val bmp = c.getInputStream().use { BitmapFactory.decodeStream(it) } ?: return@execute
                cache.put(url, bmp)
                ui.post { if (view.tag == url) view.setImageBitmap(bmp) }
            } catch (e: Exception) { /* fără miniatură */ }
        }
    }
}
