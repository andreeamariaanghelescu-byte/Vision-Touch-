package ro.vision.launcher

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.ResolveInfo
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class AllAppsActivity : Activity() {

    companion object {
        const val MODE = "mode"
        const val MODE_LAUNCH = 0
        const val MODE_ADD_FAV = 1
        const val MODE_PICK_TV = 2
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val mode = intent.getIntExtra(MODE, MODE_LAUNCH)
        val apps = loadApps()

        val grid = GridView(this).apply {
            numColumns = 6
            horizontalSpacing = dp(10)
            verticalSpacing = dp(10)
            setPadding(dp(30), dp(30), dp(30), dp(30))
            clipToPadding = false
            selector = android.graphics.drawable.ColorDrawable(0x00000000)
            adapter = object : BaseAdapter() {
                override fun getCount() = apps.size
                override fun getItem(p: Int) = apps[p]
                override fun getItemId(p: Int) = p.toLong()
                override fun getView(p: Int, convert: View?, parent: ViewGroup?): View {
                    val ri = apps[p]
                    val box = LinearLayout(this@AllAppsActivity).apply {
                        orientation = LinearLayout.VERTICAL
                        gravity = Gravity.CENTER
                        setBackgroundResource(R.drawable.bg_tile)
                        setPadding(dp(8), dp(10), dp(8), dp(10))
                        layoutParams = AbsListViewParams(dp(110))
                    }
                    box.addView(ImageView(this@AllAppsActivity).apply {
                        setImageDrawable(ri.loadIcon(packageManager))
                        layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
                    })
                    box.addView(TextView(this@AllAppsActivity).apply {
                        text = ri.loadLabel(packageManager)
                        maxLines = 1
                        ellipsize = android.text.TextUtils.TruncateAt.END
                        gravity = Gravity.CENTER
                        setTextColor(0xFFFFFFFF.toInt()); textSize = 12f
                    })
                    return box
                }
            }
            setOnItemClickListener { _, _, pos, _ ->
                val pkg = apps[pos].activityInfo.packageName
                when (mode) {
                    MODE_ADD_FAV -> {
                        val sp = getSharedPreferences(TvHelper.PREFS, Context.MODE_PRIVATE)
                        val cur = sp.getString("favs", null)?.split(",")?.filter { it.isNotEmpty() }?.toMutableList()
                            ?: mutableListOf()
                        if (!cur.contains(pkg)) cur.add(pkg)
                        sp.edit().putString("favs", cur.joinToString(",")).apply()
                        finish()
                    }
                    MODE_PICK_TV -> {
                        getSharedPreferences(TvHelper.PREFS, Context.MODE_PRIVATE)
                            .edit().putString(TvHelper.KEY_TV_PKG, pkg).apply()
                        Toast.makeText(this@AllAppsActivity, "Salvat. Apasă Home pentru canale.", Toast.LENGTH_LONG).show()
                        finish()
                    }
                    else -> {
                        if (TvHelper.launchPackage(this@AllAppsActivity, pkg)) finish()
                    }
                }
            }
        }
        setContentView(grid)
    }

    private fun AbsListViewParams(h: Int) = android.widget.AbsListView.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, h
    )

    private fun loadApps(): List<ResolveInfo> {
        val pm = packageManager
        val list = ArrayList<ResolveInfo>()
        val seen = HashSet<String>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val i = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(i, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == packageName) continue
                if (seen.add(pkg)) list.add(ri)
            }
        }
        list.sortBy { it.loadLabel(pm).toString().lowercase() }
        return list
    }
}
