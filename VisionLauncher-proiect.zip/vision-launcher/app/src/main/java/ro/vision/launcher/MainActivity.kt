package ro.vision.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var dock: LinearLayout
    private lateinit var ytRow: LinearLayout
    private var lastYtLoad = 0L

    private val defaultApps = listOf(
        "com.google.android.youtube.tv",
        "com.netflix.ninja",
        "com.spotify.tv.android",
        "com.plexapp.android",
        "com.disney.disneyplus",
        "com.amazon.amazonvideo.livingroom"
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun prefs() = getSharedPreferences(TvHelper.PREFS, Context.MODE_PRIVATE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        dock = findViewById(R.id.dock)
        ytRow = findViewById(R.id.yt_row)

        findViewById<View>(R.id.btn_tv).setOnClickListener { openTv() }
        findViewById<View>(R.id.btn_settings).setOnClickListener { showSettings() }

        loadWeather()
        // La pornire (boot) cu Home -> direct pe canale
        if (intent?.hasCategory(Intent.CATEGORY_HOME) == true && prefs().getBoolean(TvHelper.KEY_HOME_TV, true)) {
            window.decorView.post { openTv() }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Apăsare Home: deschide canalele TV. Back din TV te aduce înapoi aici.
        if (intent.hasCategory(Intent.CATEGORY_HOME) && prefs().getBoolean(TvHelper.KEY_HOME_TV, true)) {
            openTv()
        }
    }

    override fun onResume() {
        super.onResume()
        updateNetwork()
        buildDock()
        if (System.currentTimeMillis() - lastYtLoad > 15 * 60 * 1000L) loadYouTube()
    }

    // Launcherul nu trebuie să se închidă la Back
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) return true
        return super.onKeyDown(keyCode, event)
    }

    override fun onBackPressed() { /* ignorat */ }

    private fun openTv() {
        if (!TvHelper.openChannels(this)) {
            TvHelper.toastNoTv(this)
            startActivity(Intent(this, AllAppsActivity::class.java).putExtra(AllAppsActivity.MODE, AllAppsActivity.MODE_PICK_TV))
        }
    }

    // ---------- Rețea ----------
    private fun updateNetwork() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val ok = cm.activeNetworkInfo?.isConnected == true
        val tv = findViewById<TextView>(R.id.network_status)
        tv.setText(if (ok) R.string.connected else R.string.disconnected)
        tv.setTextColor(if (ok) 0xFF4DE0A0.toInt() else 0xFFFF8A80.toInt())
    }

    // ---------- Vreme ----------
    private fun loadWeather() {
        Thread {
            val w = Weather.fetch()
            runOnUiThread {
                if (w != null) {
                    findViewById<TextView>(R.id.weather_temp).text = "${w.temp}°"
                    findViewById<TextView>(R.id.weather_desc).text = w.desc
                }
            }
        }.start()
    }

    // ---------- YouTube ----------
    private fun channelIds(): List<String> {
        val s = prefs().getString("yt_channels", null)
        return if (s.isNullOrBlank()) YouTubeFeed.DEFAULT_CHANNELS
        else s.split(",").map { it.trim() }.filter { it.isNotEmpty() }
    }

    private fun loadYouTube() {
        Thread {
            val clips = YouTubeFeed.fetch(channelIds())
            runOnUiThread {
                ytRow.removeAllViews()
                if (clips.isEmpty()) {
                    ytRow.addView(TextView(this).apply {
                        setText(R.string.no_videos); setTextColor(0xCCFFFFFF.toInt()); textSize = 16f
                    })
                } else {
                    lastYtLoad = System.currentTimeMillis()
                    clips.forEach { ytRow.addView(clipCard(it)) }
                }
            }
        }.start()
    }

    private fun clipCard(c: Clip): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_tile)
            isFocusable = true
            setPadding(dp(8), dp(8), dp(8), dp(8))
            layoutParams = LinearLayout.LayoutParams(dp(210), LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                setMargins(dp(6), dp(4), dp(6), dp(4))
            }
            setOnClickListener { openVideo(c.id) }
        }
        val img = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(0x55000000)
            layoutParams = LinearLayout.LayoutParams(dp(194), dp(109))
        }
        ImageLoader.load("https://i.ytimg.com/vi/${c.id}/hqdefault.jpg", img)
        val title = TextView(this).apply {
            text = c.title
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
            setTextColor(0xFFFFFFFF.toInt()); textSize = 12f
            setPadding(0, dp(4), 0, 0)
        }
        val ch = TextView(this).apply {
            text = c.channel
            maxLines = 1
            setTextColor(0xAAFFFFFF.toInt()); textSize = 11f
        }
        card.addView(img); card.addView(title); card.addView(ch)
        return card
    }

    private fun openVideo(id: String) {
        val tries = listOf("vnd.youtube:$id", "https://www.youtube.com/watch?v=$id")
        for (u in tries) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            } catch (e: Exception) { /* următoarea variantă */ }
        }
        Toast.makeText(this, "Nu am găsit aplicația YouTube", Toast.LENGTH_LONG).show()
    }

    // ---------- Dock ----------
    private fun favorites(): List<String> {
        val s = prefs().getString("favs", null)
        if (s != null) return s.split(",").filter { it.isNotEmpty() }
        return defaultApps.filter { isInstalled(it) }
    }

    private fun isInstalled(pkg: String) = try { packageManager.getPackageInfo(pkg, 0); true } catch (e: Exception) { false }

    private fun buildDock() {
        dock.removeAllViews()
        dock.addView(tile(null, "❯") { startActivity(Intent(this, AllAppsActivity::class.java)) })
        favorites().forEach { pkg ->
            if (!isInstalled(pkg)) return@forEach
            val icon = try { packageManager.getApplicationBanner(pkg) ?: packageManager.getApplicationIcon(pkg) } catch (e: Exception) { null }
            dock.addView(tile(icon, null) { TvHelper.launchPackage(this, pkg) })
        }
        dock.addView(tile(null, "+") {
            startActivity(Intent(this, AllAppsActivity::class.java).putExtra(AllAppsActivity.MODE, AllAppsActivity.MODE_ADD_FAV))
        })
        dock.getChildAt(0)?.requestFocus()
    }

    private fun tile(icon: android.graphics.drawable.Drawable?, label: String?, onClick: () -> Unit): View {
        val size = dp(84)
        val lp = LinearLayout.LayoutParams(size, size).apply { setMargins(dp(6), 0, dp(6), 0) }
        if (icon != null) {
            return ImageView(this).apply {
                setImageDrawable(icon)
                scaleType = ImageView.ScaleType.CENTER_INSIDE
                setBackgroundResource(R.drawable.bg_tile)
                setPadding(dp(8), dp(8), dp(8), dp(8))
                isFocusable = true
                layoutParams = lp
                setOnClickListener { onClick() }
            }
        }
        return TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            textSize = 34f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundResource(R.drawable.bg_tile)
            isFocusable = true
            layoutParams = lp
            setOnClickListener { onClick() }
        }
    }

    // ---------- Setări ----------
    private fun showSettings() {
        val homeTv = prefs().getBoolean(TvHelper.KEY_HOME_TV, true)
        val items = arrayOf(
            if (homeTv) "Home deschide canalele TV: PORNIT" else "Home deschide canalele TV: OPRIT",
            "Alege aplicația de TV live",
            "Canale YouTube (ID-uri)",
            "Setările Android"
        )
        AlertDialog.Builder(this).setTitle("Setări launcher").setItems(items) { _, w ->
            when (w) {
                0 -> prefs().edit().putBoolean(TvHelper.KEY_HOME_TV, !homeTv).apply()
                1 -> startActivity(Intent(this, AllAppsActivity::class.java).putExtra(AllAppsActivity.MODE, AllAppsActivity.MODE_PICK_TV))
                2 -> editChannels()
                3 -> try { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) } catch (e: Exception) { }
            }
        }.show()
    }

    private fun editChannels() {
        val input = EditText(this)
        input.setText(channelIds().joinToString(","))
        AlertDialog.Builder(this)
            .setTitle("ID-uri canale YouTube, separate prin virgulă")
            .setView(input)
            .setPositiveButton("Salvează") { _, _ ->
                prefs().edit().putString("yt_channels", input.text.toString()).apply()
                lastYtLoad = 0
                loadYouTube()
            }
            .setNegativeButton("Anulează", null)
            .show()
    }
}
