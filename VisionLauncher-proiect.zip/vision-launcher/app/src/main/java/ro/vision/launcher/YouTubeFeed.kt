package ro.vision.launcher

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.net.HttpURLConnection
import java.net.URL

data class Clip(val id: String, val title: String, val channel: String, val published: String)

/** Citește fluxul RSS public YouTube (fără cheie API). */
object YouTubeFeed {

    // ID-uri de canale. Le poți schimba din cod sau din setări (virgulă între ele).
    val DEFAULT_CHANNELS = listOf(
        "UCAuUUnT6oDeKwE6v1NGQxug", // TED
        "UCBJycsmduvYEL83R_U4JriQ", // Marques Brownlee
        "UCK8sQmJBp8GCxrOtXWBpyEA"  // Google
    )

    fun fetch(channelIds: List<String>, perChannel: Int = 4): List<Clip> {
        val all = ArrayList<Clip>()
        for (id in channelIds) {
            try {
                all.addAll(fetchChannel(id.trim(), perChannel))
            } catch (e: Exception) {
                // sărim peste canalul care nu merge
            }
        }
        // ISO-8601 se sortează corect ca text
        return all.sortedByDescending { it.published }.take(12)
    }

    private fun fetchChannel(channelId: String, limit: Int): List<Clip> {
        val url = URL("https://www.youtube.com/feeds/videos.xml?channel_id=$channelId")
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 8000
        conn.readTimeout = 8000
        conn.setRequestProperty("User-Agent", "Mozilla/5.0")
        try {
            conn.inputStream.use { stream ->
                val p = Xml.newPullParser()
                p.setInput(stream, "UTF-8")
                val out = ArrayList<Clip>()
                var channelName = ""
                var inEntry = false
                var vid = ""
                var title = ""
                var pub = ""
                var ev = p.eventType
                while (ev != XmlPullParser.END_DOCUMENT && out.size < limit) {
                    when (ev) {
                        XmlPullParser.START_TAG -> when (p.name) {
                            "entry" -> { inEntry = true; vid = ""; title = ""; pub = "" }
                            "videoId" -> if (inEntry) vid = p.nextText()
                            "title" -> {
                                val t = p.nextText()
                                if (inEntry) title = t else channelName = t
                            }
                            "published" -> if (inEntry) pub = p.nextText()
                        }
                        XmlPullParser.END_TAG -> if (p.name == "entry") {
                            inEntry = false
                            if (vid.isNotEmpty()) out.add(Clip(vid, title, channelName, pub))
                        }
                    }
                    ev = p.next()
                }
                return out
            }
        } finally {
            conn.disconnect()
        }
    }
}
